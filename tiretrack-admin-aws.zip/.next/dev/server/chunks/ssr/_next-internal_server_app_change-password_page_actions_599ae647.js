module.exports = [
"[project]/.next-internal/server/app/change-password/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_change-password_page_actions_599ae647.js.map