module.exports=[33759,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_returns_page_actions_2ebe7825.js.map