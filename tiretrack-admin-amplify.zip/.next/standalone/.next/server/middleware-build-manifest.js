globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/11c03e5916e082fb.js",
    "static/chunks/112f346e31f991df.js",
    "static/chunks/6740f161f60c6ab5.js",
    "static/chunks/3a94daa1c77c8122.js",
    "static/chunks/42a219ea1d8fc005.js",
    "static/chunks/turbopack-686ace0bfe1b27ad.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];