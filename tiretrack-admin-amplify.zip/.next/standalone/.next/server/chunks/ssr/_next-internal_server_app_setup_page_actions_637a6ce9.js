module.exports=[76882,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_setup_page_actions_637a6ce9.js.map