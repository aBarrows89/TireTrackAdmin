module.exports=[43789,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_upcs_page_actions_2a3d59cf.js.map